package com.company;

public class GuessNumberIntents extends GuessNumber{

    private int maxIntents;
    private int intents;

    public int getMaxIntents() {
        return maxIntents;
    }

    public void setMaxIntents(int maxIntents) {
        this.maxIntents = maxIntents;
    }


    public GuessNumberIntents() {
        this.maxIntents = 10;
        this.intents = 0; // poso a 0 el número de cops que ho he intentat
        this.missatge = this.missatge +"Tens "+this.maxIntents+" oportunitats.";
    }

    /** Contructor 2 amb paràmetres: podem especificar el número d'intents
     * @param maxIntents: podrem indicar quants intents té l'usuari
     */
    public GuessNumberIntents(int maxIntents) {
        this.maxIntents = maxIntents;
        this.intents = 0; // poso a 0 el número de cops que ho he intentat
        this.missatge = this.missatge +"Tens "+this.maxIntents+" oportunitats.";
    }



    public GuessNumberIntents(int maxIntents, int minim, int maxim) {
        //es crida el constructor aqui
        super(minim,maxim);

        this.maxIntents = maxIntents;
        this.intents = 0; // poso a 0 el número de cops que ho he intentat
        this.missatge = this.missatge +"Tens "+this.maxIntents+" oportunitats.";

    }


    @Override
    public boolean comprova(int numero) {
        boolean encertat;
        encertat =  super.comprova(numero);  // Cridem al mètode comprova de la classe Pare!
        // Sabem que retorna true si el número s'ha endevinat!
        // i fals en cas contrari.
        if(encertat==false) { // No s'ha endevinat
            this.intents ++ ; // incrementem el número d'intents!
            if(this.intents == this.maxIntents) { // si s'han esgotats els intents

                this.missatge ="Has perdut! El numero cercat era "+this.numeroAleatori;

            }
            else this.missatge = this.missatge+". Et queden "+(this.maxIntents - this.intents)+".";
            // Al missatge que ha construit el pare hi afegim el numero d'intents que queden!
        }
        return encertat;
    }
}
