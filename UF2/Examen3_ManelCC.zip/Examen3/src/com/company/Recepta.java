package com.company;

public class Recepta {
    String nom;
    int num_persones;
    int difucultat;
    int[]codisIngredient;

    public Recepta(String nom, int num_persones, int difucultat, int[] codisIngredient) {
        this.nom = nom;
        this.num_persones = num_persones;
        this.difucultat = difucultat;
        this.codisIngredient = codisIngredient;
    }



    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public int getNum_persones() {
        return num_persones;
    }

    public void setNum_persones(int num_persones) {
        this.num_persones = num_persones;
    }

    public int getDifucultat() {
        return difucultat;
    }

    public void setDifucultat(int difucultat) {
        this.difucultat = difucultat;
    }

    public int[] getCodisIngredient() {
        return codisIngredient;
    }

    public void setCodisIngredient(int[] codisIngredient) {
        this.codisIngredient = codisIngredient;
    }
}
