package com.company;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner teclat =new Scanner(System.in);
        Main programa = new Main();
        String[] ingredients = {"ou","sal","patata","vedella","farina","sucre","cacau","ceba","llet","oli","avellana","bolet","all"};

        Recepta[] llibreReceptes = new Recepta[20];
        llibreReceptes[0] = new Recepta("truita amb patates",4,1,new int[]{1,2,3,8,10});
        llibreReceptes[1] = new Recepta("Crema de cacau",4,4,new int[]{9,7,11,6});
        llibreReceptes[2] = new Recepta("Fricandó",4,1,new int[]{1,2,3,8,12});
        int numReceptes = 3; // indica el número de receptes que hi ha actualment dins l’array

/*
        String e="0";
        while(!e.equals("6")){

            if (e.equals("1")){
                //programa.crearRecepta(llibreReceptes,numReceptes);
            }
            if (e.equals("2")){
                programa.triarRecepta(llibreReceptes,numReceptes);
            }
            if (e.equals("3")){
                programa.mostrarFitxa(llibreReceptes,numReceptes,ingredients);
            }
            System.out.println("-----------------------");
            System.out.print("Menú: ");
            e=teclat.next();

        }

 */

        programa.showDificultat(llibreReceptes,numReceptes); //fet
        //programa.codiIngredient(llibreReceptes,ingredients); //no fet
        //programa.mostrarFitxa(llibreReceptes,numReceptes,ingredients);//mal
        //programa.triarRecepta(llibreReceptes,numReceptes); //fet
        //programa.crearRecepta(llibreReceptes,ingredients,numReceptes);//mal


    }




    void showDificultat(Recepta[] llibreReceptes, int numReceptes){
        Scanner teclat =new Scanner(System.in);
        int i=0,j=0;
        System.out.println("Nom de plat: ");
        String rec = teclat.nextLine();
        while(i< numReceptes){
            if(llibreReceptes[i].nom.equals(rec)){

                while (j<llibreReceptes[i].difucultat){
                    System.out.print("* ");
                    j++;
                }


            }
            i++;
        }
        System.out.println();

    }



    int codiIngredient(Recepta[]llibreReceptes,String[]ingredients){
        Scanner teclat =new Scanner(System.in);
        System.out.println("Nom de ingredient: ");
        String rec = teclat.nextLine();
        int e=0;
        while (e<ingredients.length){
            if(ingredients[e].equals(rec)){
                ingredients[e]=ingredients[e++];
            }
            e--;
        }
        return 0;
    }




    void mostrarFitxa(Recepta[] llibreReceptes, int numReceptes,String[]ingredients){
        Scanner teclat =new Scanner(System.in);
        int i=0,j=0,e=0;
        System.out.println("Nom de plat: ");
        String rec = teclat.nextLine();
        while(i< numReceptes){
            if(llibreReceptes[i].nom.equals(rec)){

                System.out.println("Nom: "+llibreReceptes[i].nom);
                System.out.println("Dificultat: ");
                while (j<llibreReceptes[i].difucultat){
                    System.out.print("* ");
                    j++;
                }
                System.out.println("");
                System.out.println("Num Persones: "+llibreReceptes[i].num_persones);
                j=0;

                while (j<ingredients.length){
                        while (e< llibreReceptes[i].codisIngredient.length){

                            if (llibreReceptes[i].codisIngredient[e]==j){
                                System.out.println(ingredients[j]);
                            }
                            e++;
                        }
                    j++;
                }

            }
            i++;
        }


    }
    int triarRecepta(Recepta llibreReceptes[],int numReceptes){
        Scanner teclat =new Scanner(System.in);
        int i=0;
        System.out.println("Llista: ");
        while (i<numReceptes){
            System.out.println((i)+llibreReceptes[i].nom);
            i++;
        }
        System.out.println("Nom de plat: ");
        int rec = teclat.nextInt();
                   System.out.println(llibreReceptes[rec].nom);
                System.out.println(llibreReceptes[rec].difucultat);
                System.out.println(llibreReceptes[rec].num_persones);
        return 0;
    }

    int crearRecepta(Recepta[] llibreReceptes, String[] ingredients, int numReceptes){
        Scanner teclat =new Scanner(System.in);
        int f=0;
            System.out.println("Nova recepta:");
            String nom = teclat.nextLine();
            System.out.println("Num_persones:");
            int per=teclat.nextInt();
            System.out.println("Dificultat:");
         int dif=teclat.nextInt();
        System.out.println("ing1:");
        String ing1=teclat.nextLine();
        System.out.println("ing2:");
        String ing2=teclat.nextLine();
           // llibreReceptes[numReceptes+1]=new Recepta(nom,per,dif,codiIngredient(ing1,ing2));

        return numReceptes++;
    }


}
