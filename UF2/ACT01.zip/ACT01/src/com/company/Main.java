package com.company;
public class Main {
    public static void main(String[] args) {
        Main ma = new Main();
        int gran = ma.mesGran(4,7,2);
        System.out.println("El numero més gran es el: "+gran);
        System.out.println("La mitjana es el: "+ma.mitjana(4,7,2,8));
        if (ma.esParell(45)){ System.out.println("El num es parell"); }
        else{ System.out.println("El num es senar"); }
        if (ma.esImparell(45)){ System.out.println("El num es senar"); }
        else{ System.out.println("El num es parell"); }
        System.out.println("Hi han "+ma.comptaDigits(1)+" digits");
        if (ma.esMultiple(4,2)){ System.out.println("El num es multiple"); }
        else{ System.out.println("El num no es multimple"); }
        System.out.println("Estem a  "+ma.centigradToFarenhait(35)+"ºK");
        System.out.println("Oferta a "+ma.descomptar(50,20)+"€");
        System.out.println("Num factorial: "+ma.factorial(5));
        if (ma.esNombrePerfecte(5)){ System.out.println("El num es perfecte"); }
        else{ System.out.println("El num es inperfecte"); }
    }
    /**
     * Retorna el número més gran
     * @param n1 un número
     * @param n2 un número
     * @param n3 un número
     * @return el número més gran
     */
    int mesGran(int n1, int n2, int n3) {
        int gran;
        if(n1>=n2 && n1>=n3){ gran=n1; }
        else{
            if (n2>=n3){ gran=n2; }
            else{ gran=n3; }
        }
        return gran;
    }


    /**
     * Calcula la mitjana aritmètica de quatre números
     * @param n1 un número
     * @param n2 un número
     * @param n3 un número
     * @param n4 un número
     * @return la mitjana aritmètica dels números dels quatre paràmetres
     */
    double mitjana(double n1, double n2, double n3, double n4) {
        return (n1+n2+n3+n4)/4;
    }


    /**
     * Comprova si un número és parell
     * @param n un número
     * @return cert si el paràmetre es parell i fals en cas contrari
     */
    boolean esParell(int n) {
        if (n%2==0){ return true; }
        else{ return false; }
    }

    /**
     * Comprova si un número és imparell
     * @param n un número
     * @return cert si el paràmetre es parell i fals en cas contrari
     */
    boolean esImparell(int n) {
        if (n%2!=0){ return true; }
        else{ return false; }
    }


    /**
     * Compta els dígits d'un número
     * @param n un número
     * @return un enter amb el número de dígits de n
     */
    int comptaDigits(long n) {
        int numDigits=0;
        while (n!=0){
            n=n/10;
            numDigits++;
        }
        return numDigits;
    }


    /**
     * Comprova si un número més múltiple d'un altre
     * @param n el dividend
     * @param d el divisor
     * @return cert si n és múltiple de d i fals en cas contrari
     */
    boolean esMultiple(int n, int d) {
        if (n%d==0)
            return true;
        else
            return false;

    }



    /**
     * Converteix graus centígrads a farenheit
     * @param cent temperatura en graus centígrada
     * @return la temperatura en graus farenheit
     */
    double centigradToFarenhait(double cent) {
        return (cent+273.15);
    }


    /**
     * Aplica un percentatge de descompte a una quantitat
     * @param quantitat quantitat inicial
     * @param percentatge percentatge a descomptar
     * @return la quantitat obtinguda després d'aplicar el descompte
     */
    double descomptar(double quantitat, double percentatge) {
        return (quantitat%percentatge);
    }

    /**
     * Calcula el factorial d'un nombre enter
     * @param n un número
     * @return el valor de n!
     */
    int factorial(int n) {
        int c=n;
        while (c>1){
            n=n*(c-1);
            c--;
        }
        return n;
    }





    /**
     * Comprova si un número és perfecte, és a dir, que el seu valor és igual a
     * la suma dels seus divisors
     * @param n un número
     * @return cert si el número és perfecte i fals en cas contrari
     */
    boolean esNombrePerfecte(int n) {
        int b=1,d=0, e=0;
        while(b<n){
            int c = n%b;
            if(c==0){ d=d+b; }
            if (d==n){ e=1; }
            else{ e=0; }
            b++;
        }
        if (e==1){ return true; }
        else{ return false; }
    }
}
