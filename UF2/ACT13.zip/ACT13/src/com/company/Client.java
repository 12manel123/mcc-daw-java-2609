package com.company;

public class Client {
        String nom;
        int telefon;

    public Client(String nom, int telefon) {
        this.nom = nom;
        this.telefon = telefon;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public int getTelefon() {
        return telefon;
    }

    public void setTelefon(int telefon) {
        this.telefon = telefon;
    }
}
